# RecoverX (Starter)
Minimal Android app ready for GitHub Actions.
- No Gradle wrapper required (the action installs Gradle).
- Builds a debug APK on every push to `main`.
- Find the APK in Actions → the latest run → Artifacts.